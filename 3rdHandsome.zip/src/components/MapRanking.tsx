import { Text, View , Button} from 'react-native'
import React from 'react'
import LocationRankingComponent from './LocationRankingComponent'

const MapRanking = () => {
    return (
        <>
        <LocationRankingComponent />
        <LocationRankingComponent />
        <LocationRankingComponent />
        <LocationRankingComponent />
        <LocationRankingComponent />
        <LocationRankingComponent />


        </>
        )
}

export default MapRanking